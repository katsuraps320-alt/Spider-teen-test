# SPIDER TEENERIX

An original, mobile-first 3D/2.5D open-world superhero action game.
Hero: **Kairo Teenerix** ("Teenerix") · City: **Veyron City** · Power: **Vortex Threads**

This is an original IP — no Marvel, Spider-Man, or other copyrighted characters, logos, suits, or music are used.

## Files
- `index.html` — page structure, HUD, phone UI, touch controls
- `style.css` — dark tactical mobile UI
- `game.js` — engine bootstrap, render loop, day/night, HUD/state
- `player.js` — movement, jump, Vortex Threads swing system, camera, emotes
- `input.js` — virtual joystick, camera swipe, action buttons
- `city.js` — procedural Veyron City (roads, buildings, park, training ground, shops)
- `combat.js` — player combos, Vortex attack, enemy AI (drone/gang/heavy/ranged/vortex)
- `npc.js` — pedestrians, dialogue, fleeing behaviour
- `crimes.js` — random crime spawner + scanner
- `police.js` — wanted-level response, units, scanner messages
- `missions.js` — mission chain, objectives, rewards
- `weather.js` — clear/rain/heavy rain/fog with particle effects
- `phone.js` — in-game phone: HOME / CRIME / MAP / POLICE / MUSIC / NEWS
- `music.js` — personal music player (loads YOUR audio files locally, never uploaded)
- `save.js` — localStorage save/load/new game

Three.js is loaded from a CDN (`cdn.jsdelivr.net`), so **an internet connection is required on first load** to fetch the engine (it's cached by the browser afterward).

## Running on Android

**Easiest: local web server via Termux**

1. Copy the whole `spider-teenerix` folder onto your phone (e.g. into `/sdcard/spider-teenerix`).
2. Install Termux from F-Droid (or your existing Termux setup).
3. In Termux:
   ```
   pkg install python
   cd /sdcard/spider-teenerix
   python -m http.server 8080
   ```
4. Open Chrome (or any Android browser) and go to:
   ```
   http://localhost:8080
   ```
5. Tap **NEW GAME** and allow the page to load Three.js (needs data/wifi once).

You must use a real HTTP server (not `file://`) — browsers block ES module imports and the File API's blob URLs can behave inconsistently under `file://`.

**Alternative:** host the folder on any static host (GitHub Pages, Netlify, Vercel, etc.) and open the URL on your phone.

## Controls
- **Left thumb:** virtual joystick — walk / run / sprint (hold BOOST while moving on ground to sprint)
- **Right side swipe:** camera look
- **JUMP** — jump / wall-jump when wall-running
- **ATTACK** — 3-hit melee combo
- **VORTEX** — while airborne near a building: Vortex Attach (starts a swing). While grounded: Vortex AoE attack on nearby enemies.
- **BOOST** — hold while swinging to build extra momentum; hold while running on ground to sprint
- **RELEASE** — let go of the current swing early
- **EMOTE** — opens a radial menu (Wave / Peace / Salute / Vortex) — playable mid-swing, doesn't interrupt movement

## Phone
Tap the phone icon (top right) to open:
- **HOME** — status + notifications
- **CRIME** — active crimes with distance/severity, tap TRACK to head toward one
- **MAP** — minimap with player, crimes, and mission markers
- **POLICE** — live scanner feed tied to your wanted level
- **MUSIC** — tap "CHOOSE AUDIO FILES" to pick MP3/WAV/OGG/M4A files from your device; playback continues seamlessly while you play (jumping, swinging, fighting, opening the phone never stops it)
- **NEWS** — rotating Veyron City headlines

## Save data
Progress (level, XP, money, reputation, missions, position, settings) is saved automatically every 30 seconds and on demand via Settings, using `localStorage` — fully offline, no account or server needed.

## Performance notes
Graphics quality (Settings → Graphics) scales pixel ratio, shadow rendering, and draw distance for weaker Android devices. Enemy counts, NPC counts, and particle counts are capped for 60/30 FPS targets.
